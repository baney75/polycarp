import{require_jszip_min}from"./chunk-YDWMPW53.js";import"./chunk-H4QX2JIU.js";export default require_jszip_min();
//# sourceMappingURL=jszip.min-IK7AF2ME.js.map
