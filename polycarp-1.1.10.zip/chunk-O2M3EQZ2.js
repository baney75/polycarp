import{init_define_TABKYRA_BUILD,init_process_shim}from"./chunk-H4QX2JIU.js";init_define_TABKYRA_BUILD();init_process_shim();var hasCopilotVisionInput=()=>!1,buildCopilotDynamicHeaders=()=>({});export{hasCopilotVisionInput,buildCopilotDynamicHeaders};
//# sourceMappingURL=chunk-O2M3EQZ2.js.map
